# Removes The Snack Lab WhatsApp bot's service. Asks whether to also delete its setup and WhatsApp login.
$ErrorActionPreference = 'Stop'

$admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $admin) {
  Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
  exit
}

try {
  $dest = Join-Path $env:ProgramData 'SnackLabBot'
  $svc = Join-Path $dest 'SnackLabBot.exe'
  if (Get-Service -Name SnackLabBot -ErrorAction SilentlyContinue) {
    Write-Host "Stopping and removing the service"
    Stop-Service -Name SnackLabBot -Force -ErrorAction SilentlyContinue
    if (Test-Path $svc) { & $svc uninstall | Out-Null } else { & sc.exe delete SnackLabBot | Out-Null }
  }
  Write-Host ""
  Write-Host "The bot is removed. Its setup and WhatsApp login are still in $dest\data."
  $answer = Read-Host "Delete them too? The WhatsApp number would need linking again (y/N)"
  $all = $answer -match '^(y|yes)$'
  # From a separate window after this one closes: this script itself lives in that folder.
  $target = if ($all) { $dest } else { $null }
  if ($all) {
    Start-Process cmd.exe -ArgumentList "/c timeout /t 3 /nobreak >nul & rmdir /s /q `"$target`"" -WindowStyle Hidden
    Write-Host "Everything will be deleted in a few seconds."
  } else {
    Get-ChildItem $dest | Where-Object { $_.Name -ne 'data' -and $_.Name -notlike 'uninstall.*' } | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "Kept $dest\data. Installing again picks it up."
  }
} catch {
  Write-Host "Uninstall failed: $($_.Exception.Message)" -ForegroundColor Red
}
Read-Host "Press Enter to close"

# Installs (or updates) The Snack Lab WhatsApp bot as a Windows service in C:\ProgramData\SnackLabBot.
# Keeps an existing setup and WhatsApp login. Run install.cmd (it asks for Administrator rights).
# -Unattended: no questions, no browser (the release workflow's test install).
param([switch]$Unattended)
$ErrorActionPreference = 'Stop'

$admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $admin) {
  $extra = if ($Unattended) { ' -Unattended' } else { '' }
  Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"$extra"
  exit
}

function Step($text) { Write-Host "  - $text" }
try {
  $src = $PSScriptRoot
  $dest = Join-Path $env:ProgramData 'SnackLabBot'
  $svc = Join-Path $dest 'SnackLabBot.exe'
  Write-Host ""
  Write-Host "The Snack Lab WhatsApp bot: installing in $dest" -ForegroundColor Green

  foreach ($f in 'node.exe', 'SnackLabBot.exe', 'SnackLabBot.xml', 'boot.mjs') {
    if (-not (Test-Path (Join-Path $src $f))) { throw "$f is missing from this folder. Unzip the whole download first, then run install.cmd from it." }
  }
  $app = Get-ChildItem (Join-Path $src 'app') -Directory | Where-Object { $_.Name -match '^b\d+$' } | Sort-Object { [int]$_.Name.Substring(1) } | Select-Object -Last 1
  if (-not $app) { throw "The app folder is missing. Unzip the whole download first." }
  $build = [int]$app.Name.Substring(1)

  # An install already there: stop it first (it starts again at the end).
  $existing = Get-Service -Name SnackLabBot -ErrorAction SilentlyContinue
  if ($existing -and $existing.Status -ne 'Stopped') {
    Step "Stopping the running bot"
    Stop-Service -Name SnackLabBot -Force
    (Get-Service -Name SnackLabBot).WaitForStatus('Stopped', [TimeSpan]::FromSeconds(30))
  }

  Step "Copying files"
  New-Item -ItemType Directory -Force -Path $dest, (Join-Path $dest 'versions'), (Join-Path $dest 'data') | Out-Null
  foreach ($f in 'node.exe', 'SnackLabBot.exe', 'SnackLabBot.xml', 'uninstall.cmd', 'uninstall.ps1', 'README.txt') {
    if (Test-Path (Join-Path $src $f)) { Copy-Item (Join-Path $src $f) $dest -Force }
  }

  # The build in this download, unless a newer one has already updated itself in.
  $stateFile = Join-Path $dest 'state.json'
  $state = $null
  if (Test-Path $stateFile) { $state = Get-Content $stateFile -Raw | ConvertFrom-Json }
  $installed = 0
  if ($state -and $state.current -match '^b\d+$') { $installed = [int]$state.current.Substring(1) }
  if ($build -ge $installed) {
    Copy-Item $app.FullName (Join-Path $dest 'versions') -Recurse -Force
    Copy-Item (Join-Path $src 'boot.mjs') $dest -Force
    $bad = @()
    if ($state -and $state.bad) { $bad = @($state.bad | Where-Object { $_ -ne $app.Name }) }
    $new = [ordered]@{
      current  = $app.Name
      good     = $(if ($state -and $state.good) { $state.good } else { '' })
      previous = $(if ($state -and $state.current) { $state.current } else { '' })
      bad      = $bad
      attempts = @{}
    }
    # UTF-8 without a byte-order mark (Set-Content -Encoding UTF8 adds one in Windows PowerShell).
    [IO.File]::WriteAllText($stateFile, ($new | ConvertTo-Json -Depth 4), (New-Object Text.UTF8Encoding $false))
    Step "Build $build"
  } else {
    Step "Keeping build $installed (newer than this download's $build)"
  }

  # The WhatsApp login and the Google key: only Windows itself (SYSTEM) and Administrators can read them.
  Step "Protecting the data folder"
  & icacls (Join-Path $dest 'data') /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' | Out-Null

  # Asleep, the bot can't post: never sleep or hibernate while plugged in.
  Step "Keeping the computer awake when plugged in"
  & powercfg /change standby-timeout-ac 0
  & powercfg /change hibernate-timeout-ac 0

  if (-not $existing) {
    Step "Adding the Windows service"
    & $svc install | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Couldn't add the service (code $LASTEXITCODE)." }
  }
  # Restart on failure is set in SnackLabBot.xml; Windows' own recovery as a second line.
  & sc.exe failure SnackLabBot reset= 3600 actions= restart/10000/restart/30000/restart/60000 | Out-Null

  Step "Starting it"
  Start-Service -Name SnackLabBot
  Start-Sleep -Seconds 4
  Write-Host ""
  Write-Host "Done. The bot runs by itself from now on, also after a restart." -ForegroundColor Green
  Write-Host "Its status page: http://localhost:7071 (opening it now). Finish the setup there."
  if (-not $Unattended) { Start-Process 'http://localhost:7071' }
} catch {
  Write-Host ""
  Write-Host "Install failed: $($_.Exception.Message)" -ForegroundColor Red
  if ($Unattended) { exit 1 }
}
Write-Host ""
if (-not $Unattended) { Read-Host "Press Enter to close" }

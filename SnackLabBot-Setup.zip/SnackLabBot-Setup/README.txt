The Snack Lab WhatsApp bot
=========================

Posts each order to the customer's WhatsApp group, and updates to your staff group. It runs on this computer by
itself: it starts with Windows (no need to sign in), restarts itself if it stops, and updates itself.

Install
-------
1. Unzip the whole download to a folder (for example Downloads\SnackLabBot-Setup).
2. Double-click install.cmd and allow it to make changes (Administrator).
3. Your browser opens the bot's status page: http://localhost:7071
4. Under Setup at the bottom of that page:
   - paste the Google Sheet's link,
   - choose the Google key file (.json) you were given,
   - press Save.
5. Link the bot's WhatsApp number from the dashboard: Settings -> WhatsApp -> Link. The QR code also shows on the
   status page. Scan it with the bot's phone: WhatsApp -> Linked devices -> Link a device.

The status page
---------------
Open http://localhost:7071 on this computer any time. At the top it says Working, or what's wrong; each problem
says what to do about it. "Download the full log" saves the log to send to the developer.

Keep in mind
------------
- Keep the computer on and plugged in. The installer stops it sleeping while plugged in.
- Only one computer may run the bot. Two copies on one WhatsApp number knock each other off.
- Use the bot's own number, never the business's main WhatsApp number.

Remove
------
Double-click uninstall.cmd in C:\ProgramData\SnackLabBot (or in this folder). It asks whether to also delete the
setup and the WhatsApp login.

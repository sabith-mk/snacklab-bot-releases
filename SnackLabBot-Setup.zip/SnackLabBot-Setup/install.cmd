@echo off
rem Installs (or updates) The Snack Lab WhatsApp bot as a Windows service. Asks for Administrator rights.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"

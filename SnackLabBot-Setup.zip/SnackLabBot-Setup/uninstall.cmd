@echo off
rem Removes The Snack Lab WhatsApp bot's service. Asks for Administrator rights.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall.ps1"
